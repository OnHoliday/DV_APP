require(shiny)
require(leaflet)
require(htmltools)
require(ggplot2)
library(shinythemes)
library(shinydashboard)



df.station <- read.csv("~/dane/station.csv", header=TRUE, sep=",")
df.trip <- read.csv("~/dane/trip.csv", header=TRUE, sep=",")
