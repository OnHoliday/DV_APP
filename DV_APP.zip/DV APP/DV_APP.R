require(shiny)
require(leaflet)
require(htmltools)
require(ggplot2)
library(shinythemes)
df <- read.csv("station.csv", header=TRUE, sep=",")

ui <- fluidPage(theme = shinytheme("superhero"),
  titlePanel("Examples with spatial data"),
  tabsetPanel(
    #First example
    tabPanel("1st example", leafletOutput("firstExample", height=800)),
    #Second example
    tabPanel("2nd example", 
             # Sidebar layout with input and output definitions ----
             sidebarLayout(position = "left",
                           
                           # Sidebar panel for inputs ----
                           sidebarPanel(
                             selectInput("neighboorhood", "Choose something:",
                                         choices = c(1, 2))
                           ),
                           
                           # Main panel for displaying outputs ----
                           mainPanel(
                             leafletOutput("secondExample", height=700)
                           )
             )
    )
    #Third example:
    #tabPanel()
  )
  
)

server <- function(input, output) {
  
  tmp.df <- df[sample(nrow(df), 10), ]
  
  #38.713889, -9.139444
  
  output$firstExample <- renderLeaflet({
  
    
    leaflet(tmp.df) %>%
      #Here is where tiles providers live
      addTiles(group="OSM") %>%#OSM is default tile providor
      addProviderTiles(providers$Esri.WorldImagery, group = 'Aerial Imaginary') %>%
      addProviderTiles(providers$CartoDB.Positron, group = 'CartoDB') %>%
      #This is Lisbon
      setView(
        lng=-122.335167,
        lat=47.608013,
        zoom=12
      ) %>%
      #Adding airbnb houses
      addMarkers(~long, ~lat, popup=~htmlEscape(name)) %>%
      #Group of Layers
      addLayersControl(
        baseGroups = c('OSM', 'Aerial Imaginary', 'CartoDB'),
        #overlayGroups = c('ex_data')
        options = layersControlOptions(collapsed = FALSE)
      )
    
    
  })
  
  
  
 output$plot <- renderPlot({
   p <- ggplot(tmp.df) +
     geom_density(alpha = 0.2, fill = "#80EDBA") + 
     geom_vline(aes(xintercept = mean(price), color = "mean"), linetype = "dashed", size = 0.8) + 
     scale_color_manual(name = "AirBnB Statiscics", values = c("mean" = "#F80"))
   print(p)
 })
  
  
  output$secondExample <- renderLeaflet({
    
    observeEvent(input$secondExample_marker_click, {
      click <- input$secondExample_marker_click
    })
    
    #Temporary dataframe

    leaflet(tmp.df) %>%
      #Here is where tiles providers live
      addTiles() %>%#OSM is default tile providor
      #This is Lisbon
      setView(
        lng=-122.335167,
        lat=47.608013,
        zoom=12
      )%>%
    addMarkers(~long, ~lat)
      
    
  })
  
}

shinyApp(ui, server)