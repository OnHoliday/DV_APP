
ui <- navbarPage(title =  "CITY BIKE - Seattle", position = "fixed-top",  footer = 'AAA', collapsible = TRUE, fluid = TRUE,
                 theme = shinytheme("slate"),
                 tabPanel("HOMEPAGE",
                          #includeCSS("styles.css"),
                          headerPanel("New Application")),
                 tabPanel("STATIONS",
                          fluidPage(
                            titlePanel("Station - Analysis"),
                            sidebarLayout(
                              sidebarPanel("our inputs will go here", 
                                           sliderInput("numberInput", "Number", min = 1, max = 58,
                                                       value = c(10), pre = "nr "),
                                           radioButtons("typeInput", "Product type",
                                                        choices = c("BEER", "REFRESHMENT", "SPIRITS", "WINE"),
                                                        selected = "WINE")),
                              mainPanel(br(), br(),
                                leafletOutput("firstExample", height=700, width = 700))))),
                 tabPanel("TRIPS", 
                          sidebarLayout(position = "right",
                                        sidebarPanel(
                                          selectInput("neighboorhood", "Choose something:",
                                                      choices = c(1, 2))
                                        ),
                                        mainPanel(
                                          leafletOutput("secondExample", height=700)
                                        )
                          )
                 ),
                 tabPanel("ANLYSIS"),
                 navbarMenu("MORE",
                            tabPanel("SUMMARY"),
                            "----",
                            tabPanel("DATASET", dataTableOutput("mytable1")),
                            "----",
                            tabPanel("ABOUT US")
                            
                            
                            #Third example
                            #tabPanel()
                 )

                 
)