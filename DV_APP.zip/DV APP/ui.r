require(shiny)
require(leaflet)
require(htmltools)
require(ggplot2)
library(shinythemes)

df.station <- read.csv("C:/Users/Konrad/Desktop/DV APP/dane/station.csv", header=TRUE, sep=",")
df.trip <- read.csv("C:/Users/Konrad/Desktop/DV APP/dane/trip.csv", header=TRUE, sep=",")

ui <- navbarPage(title =  "CITY BIKE - Seattle", position = "fixed-top",  footer = 'AAA', collapsible = TRUE, fluid = TRUE, theme = shinytheme("superhero"),
                 tabPanel("HOMEPAGE"),
                 tabPanel("STATIONS", leafletOutput("firstExample", height=3000, width = 300)),
                 tabPanel("TRIPS", 
                          sidebarLayout(position = "right",
                                        sidebarPanel(
                                          selectInput("neighboorhood", "Choose something:",
                                                      choices = c(1, 2))
                                        ),
                                        mainPanel(
                                          leafletOutput("secondExample", height=700)
                                        )
                          )
                 ),
                 tabPanel("ANLYSIS"),
                 navbarMenu("MORE",
                            tabPanel("SUMMARY"),
                            "----",
                            tabPanel("DATASET"),
                            "----",
                            tabPanel("ABOUT US")
                            
                            
                            #Third example
                            #tabPanel()
                 )
                 
)