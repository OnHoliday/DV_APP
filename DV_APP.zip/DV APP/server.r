
server <- function(input, output) {
  
  #print(input$priceInput[1])
  numOfStation <- reactive({
    df.station[sample(nrow(df.station),input$numberInput[1]), ] })
  
  tmp.df <- df.station[sample(nrow(df.station), 10), ]
  
  #distt <- hav.dist(long1, lat1, long2, lat2)
  
  output$firstExample <- renderLeaflet({
    
    
    leaflet(numOfStation()) %>%
      #Here is where tiles providers live
      addTiles(group="OSM") %>%#OSM is default tile providor
      addProviderTiles(providers$Stamen.TonerLite) %>%
      #addProviderTiles(providers$Thunderforest.TransportDark) %>%
      #This is Seattle
      setView(
        lng=-122.335167,
        lat=47.608013,
        zoom=12
      ) %>%
      #Adding airbnb houses
      addMarkers(~long, ~lat, popup=~htmlEscape(name))
    #Group of Layers
  })
  
  output$secondExample <- renderLeaflet({
    
    observeEvent(input$secondExample_marker_click, {
      click <- input$secondExample_marker_click
    })
    
    #Temporary dataframe
    
    leaflet(tmp.df) %>%
      #Here is where tiles providers live
      addTiles(group="OSM") %>%#OSM is default tile providor
      #addProviderTiles(providers$CartoDB.Positron) %>%
      #addProviderTiles(providers$Stamen.TonerLite) %>%
      addProviderTiles(providers$Esri.WorldImagery) %>%
      #This is Seattle
      setView(
        lng=-122.335167,
        lat=47.608013,
        zoom=12
      )%>%
      addMarkers(~long, ~lat, popup=~htmlEscape(name))
    
    
  })
  
  output$mytable1 = renderDataTable({
      df.trip
    }, options = list(aLengthMenu = c(5, 35, 50), iDisplayLength = 8))
  
}
#shinyApp(ui, server)