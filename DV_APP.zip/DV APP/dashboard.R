library(shinydashboard)
require(shiny)

ui <- dashboardPage(
  dashboardHeader(title = "Basic dashboard", dropdownMenu(type = "tasks", badgeStatus = "success",
                                                          taskItem(value = 90, color = "green",
                                                                   "Documentation"
                                                          ),
                                                          taskItem(value = 17, color = "aqua",
                                                                   "Project X"
                                                          ),
                                                          taskItem(value = 75, color = "yellow",
                                                                   "Server deployment"
                                                          ),
                                                          taskItem(value = 80, color = "red",
                                                                   "Overall project"
                                                          )
  
  )),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Widgets", tabName = "widgets", icon = icon("th"))
    )
  ),
  ## Body content
  dashboardBody(
    tabItems(
      # First tab content
      tabItem(tabName = "dashboard",
              fluidRow(
                box(plotOutput("plot1", height = 250)),
                
                box(
                  title = "Controls",
                  sliderInput("slider", "Number of observations:", 1, 100, 50)
                )
              )
      ),
      
      # Second tab content
      tabItem(tabName = "widgets",
              h2("Widgets tab content")
      )
    )
  )
)


server <- function(input, output) {
  set.seed(122)
  histdata <- rnorm(500)
  
  output$plot1 <- renderPlot({
    data <- histdata[seq_len(input$slider)]
    hist(data)
  })
}

shinyApp(ui, server)